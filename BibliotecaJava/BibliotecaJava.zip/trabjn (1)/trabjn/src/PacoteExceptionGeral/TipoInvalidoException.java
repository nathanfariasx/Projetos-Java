package PacoteExceptionGeral;

public class TipoInvalidoException extends RuntimeException{
    public TipoInvalidoException (String msg){
        super(msg);
    }
}

