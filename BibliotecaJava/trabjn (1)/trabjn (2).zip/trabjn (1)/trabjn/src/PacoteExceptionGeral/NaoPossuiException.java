package PacoteExceptionGeral;

public class NaoPossuiException extends RuntimeException{
    public NaoPossuiException(String msg){
        super(msg);
    }
}
