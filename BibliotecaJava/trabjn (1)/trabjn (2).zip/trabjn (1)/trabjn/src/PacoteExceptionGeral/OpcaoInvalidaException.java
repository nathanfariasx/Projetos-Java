package PacoteExceptionGeral;

public class OpcaoInvalidaException extends RuntimeException{

    public OpcaoInvalidaException(String msg){
        super(msg);
    }
}
