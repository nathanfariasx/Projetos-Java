package PacoteExceptionGeral;

public class UsuarioJaCadastradoException extends RuntimeException{
    public UsuarioJaCadastradoException(String msg){
        super(msg);
    }
}
